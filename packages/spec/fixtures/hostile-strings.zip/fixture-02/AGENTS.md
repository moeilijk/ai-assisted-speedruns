Play the GUI fake. <script>alert("aas")</script><img src=x onerror=alert(1)>"'&‮
