Play the GUI fake.
password=hunter2 at /home/someone/secret
