# GUI Fake

`game.observe()` returns `{turn}`; `game.act()` returns `{turn}`.
